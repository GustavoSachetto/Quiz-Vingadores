package com.example.quiz_vingadores;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class Pergunta1 extends AppCompatActivity {

    TextView txNome;
    Button btProxima;
    RadioGroup rgPergunta1;
    Integer pontuacao;
    String nomeRecebido;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pergunta1);

        txNome = findViewById(R.id.txtNome);
        btProxima = findViewById(R.id.btnProxima1);
        rgPergunta1 = findViewById(R.id.rgpPergunta1);

        Intent abrirPergunta1 = getIntent();
        Bundle valor = abrirPergunta1.getExtras();
        nomeRecebido = valor.getString("nome");
        txNome.setText(nomeRecebido);

        btProxima.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int escolha;

                escolha = rgPergunta1.getCheckedRadioButtonId();

                if (escolha == R.id.rbtC) {
                    pontuacao = pontuacao + 1;
                }

                Intent abrirPergunta2 = new Intent(Pergunta1.this, Pergunta1.class);
                abrirPergunta2.putExtra("pontuacao", pontuacao);
                abrirPergunta2.putExtra("nome", nomeRecebido);
                startActivity(abrirPergunta2);
            }
        });
    }
    public void onBackPressed(){
        AlertDialog.Builder mensagem = new AlertDialog.Builder(Pergunta1.this);
        mensagem.setTitle("Confirmar");
        mensagem.setMessage("Deseja sair?");
        mensagem.setPositiveButton("Sim", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                finish();
            }
        });
        mensagem.setNegativeButton("Não", null);
        mensagem.setCancelable(false);
        mensagem.show();
    }
}